<?php
/**
 * Single Product title
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>

<h1 itemprop="name"><?php the_title(); ?></h1>