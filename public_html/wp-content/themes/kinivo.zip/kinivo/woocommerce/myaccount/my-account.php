<?php
/**
 * My Account page
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

wc_print_notices(); 

// Retrieve The Post's Author ID
$author_id = $GLOBALS['current_user']->ID;
// Set the image size. Accepts all registered images sizes and array(int, int)
$size = 'thumbnail';

// Get the image URL using the author ID and image size params
$imgURL = get_cupp_meta($author_id, $size);

?>
<?php do_action( 'woocommerce_before_my_account' ); ?>
<div class="my-account-content">
	<div class="wrapper wrap">
		<div class="bread">Home / My Account</div>
		<div class="dash">
			<div class="top">
				<ul class="responsive-menu">
					<li class="user">
						<span class="profile-picture" style="background-image: url('<?php echo $imgURL; ?>');"></span>
						<span class="user-name"><?php echo $GLOBALS['current_user']->user_firstname; ?></span>
						<a class="drop-menu">Order History</a>
					</li>
					<li>
						<a class="active">Order History</a>
					</li>
					<li>
						<a>My Wish List</a>
					</li>
					<li>
						<a>Personal Information</a>
					</li>
				</ul>
				<ul class="rest-menu-responsive">
					<li>
						<a class="active">Order History</a>
					</li>
					<li>
						<a>My Wish List</a>
					</li>
					<li>
						<a>Personal Information</a>
					</li>
				</ul>
				<h1>Order History</h1>
				<div class="search">
					<input type="text" placeholder="TITLE, DEPARTMENT, RECIPIENT">
					<input type="submit" value="search">
				</div>
			</div>
			<ul class="menu">
				<li class="user">
					<span class="profile-picture" style="background-image: url('<?php echo $imgURL; ?>');"></span>
					<span class="user-name"><?php echo $GLOBALS['current_user']->user_firstname; ?></span>
				</li>
				<li>
					<a class="active">Order History</a>
				</li>
				<li>
					<a>My Wish List</a>
				</li>
				<li>
					<a>Personal Information</a>
				</li>
			</ul>
			<?php wc_get_template( 'myaccount/my-orders.php', array( 'order_count' => $order_count ) ); ?>
			<!-- <table class="information-table">
				<thead>
					<tr>
						<th>Order Information</th>
						<th>Products Ordered</th>
						<th>
							<select name="" id="">
								<option value="">View All History</option>
								<option value="">View EX</option>
							</select>
						</th>
					</tr>
				</thead>
				<body>
					<tr>
						<td>
							<div>
								<span>Order Placed</span>
								<span class="order-placed">April 24 - 2014</span>
							</div>
							<div>
								<span>Order Number</span>
								<span>1110-9876548-000</span>
							</div>
							<div>
								<span>Recipient</span>
								<span>Fly 44956 John Doe:</span>
							</div>
							<div>
								<span><b>Total:</b> $99.99</span>
							</div>
						</td>
						<td>
							<div class="history-product">
								<img src="img/misc/car-dummy2.png" class="pr" alt="">
								<div class="product-info">
									<h1>Kinivo BTH240 Color Black Premium Edition.</h1>
									<a href="">
										<img src="img/icn/small-car.png" alt="">BUY AGAIN
									</a>
								</div>
							</div>
							<div class="history-product">
								<img src="img/misc/car-dummy2.png" class="pr" alt="">
								<div class="product-info">
									<h1>Kinivo BTH240 Color Black Premium Edition.</h1>
									<a href="">
										<img src="img/icn/small-car.png" alt="">BUY AGAIN
									</a>
								</div>
							</div>
							<div class="history-product">
								<img src="img/misc/car-dummy2.png" class="pr" alt="">
								<div class="product-info">
									<h1>Kinivo BTH240 Color Black Premium Edition.</h1>
									<a href="">
										<img src="img/icn/small-car.png" alt="">BUY AGAIN
									</a>
								</div>
							</div>
							<a class="button green standar-nowidth view-history-responsive show-modal" data-modal="view-detail">Order detail</a>
							<a class="button green standar-nowidth view-history-responsive">Replace/Question</a>
						</td>
						<td>
							<a class="button green standar-nowidth show-modal" data-modal="view-detail">Order detail</a>
							<a class="button green standar-nowidth">Replace/Question</a>
						</td>
					</tr>
					<tr>
						<td>
							<div>
								<span>Order Placed</span>
								<span class="order-placed">April 24 - 2014</span>
							</div>
							<div>
								<span>Order Number</span>
								<span>1110-9876548-000</span>
							</div>
							<div>
								<span>Recipient</span>
								<span>Fly 44956 John Doe:</span>
							</div>
							<div>
								<span><b>Total:</b> $99.99</span>
							</div>
						</td>
						<td>
							<div class="history-product">
								<img src="img/misc/car-dummy2.png" class="pr" alt="">
								<div class="product-info">
									<h1>Kinivo BTH240 Color Black Premium Edition.</h1>
									<a href="">
										<img src="img/icn/small-car.png" alt="">BUY AGAIN
									</a>
								</div>
							</div>
							<a class="button green standar-nowidth view-history-responsive show-modal" data-modal="view-detail">Order detail</a>
							<a class="button green standar-nowidth view-history-responsive">Replace/Question</a>
						</td>
						<td>
							<a class="button green standar-nowidth show-modal" data-modal="view-detail">Order detail</a>
							<a class="button green standar-nowidth">Replace/Question</a>
						</td>
					</tr>
				</body>
			</table> -->
			<div class="top">
				<a class="prev"></a>
				<span class="pages">Page 1 - 2</span>
				<a class="next"></a>
			</div>
		</div>
	</div>
</div>

<p class="myaccount_user">
	<?php
	// printf(
	// 	__( 'Hello <strong>%1$s</strong> (not %1$s? <a href="%2$s">Sign out</a>).', 'woocommerce' ) . ' ',
	// 	$current_user->display_name,
	// 	wp_logout_url( get_permalink( wc_get_page_id( 'myaccount' ) ) )
	// );

	// printf( __( 'From your account dashboard you can view your recent orders, manage your shipping and billing addresses and <a href="%s">edit your password and account details</a>.', 'woocommerce' ),
	// 	wc_customer_edit_account_url()
	// );
	?>
</p>

<?php do_action( 'woocommerce_after_my_account' ); ?>



<?php //wc_get_template( 'myaccount/my-downloads.php' ); ?>



<?php //wc_get_template( 'myaccount/my-address.php' ); ?>
