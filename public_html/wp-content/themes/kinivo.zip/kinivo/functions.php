<?php
//Theme JS
function theme_js(){
	wp_enqueue_scripts('jquery');
}
add_action( 'init', 'theme_js' );
show_admin_bar(false);
add_theme_support( 'woocommerce' );